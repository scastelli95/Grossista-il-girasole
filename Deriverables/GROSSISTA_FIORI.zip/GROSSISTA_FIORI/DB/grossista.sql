 
drop database if exists grossista_fiori1;
create database if not exists grossista_fiori1;
use grossista_fiori1;

CREATE TABLE `settore` (
  `numero` int(100) NOT NULL,
  `descrizione` text,
  PRIMARY KEY (`numero`)
);

insert into settore values (1, 'settore di fiori');
insert into settore values (2, 'settore di fiori artificiali');
insert into settore values (3, 'settore di piante');
insert into settore values (4, 'settore di oggettistica');
insert into settore values (5, 'settore di attrezzatura');
insert into settore values (6, 'settore di scarico');

CREATE TABLE `negozio` (
  `nome_negozio` varchar(30) NOT NULL,
  `num_telefono` varchar(20) DEFAULT NULL,
  `e_mail` varchar(100) DEFAULT NULL,
  `fax` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`nome_negozio`)
);

insert into negozio values ('fiori','0976885432',null,'0976885432');
insert into negozio values ('piante','0876885932','t.null@gmail.com','0976885782');
insert into negozio values ('piante&fiori','3667856437','shhh@gmail.com',null);
insert into negozio values ('florcamp',null,'florcmp@libero.com','098756432');
insert into negozio values ('florcamp0',098567832,'florcmp@libero.com','098756432');

CREATE TABLE `clienti` (
`codice` INT UNSIGNED AUTO_INCREMENT,
 `tipo_cliente` char(30),
  `nome` varchar(30) NOT NULL,
 `cognome` varchar(30) NOT NULL,
 `citta` varchar(30),
 `via` varchar(30),
 `nome_negozio` varchar(30) DEFAULT NULL,
 `partita_IVA` varchar(12) DEFAULT NULL,
 `email` varchar(50) NOT NULL,
 `password` varchar(30) NOT NULL,
 PRIMARY KEY (`codice`)
 );

insert into clienti(tipo_cliente,nome,cognome,citta,via,nome_negozio,partita_IVA,email,password) values ('piccola impresa','annamaria','santomauro','agropoli','moio','il girasole','34312345678','annamaria@gmail.com','gira');
insert into clienti(tipo_cliente,nome,cognome,citta,via,nome_negozio,partita_IVA,email,password) values ('grande impresa','antonio','rossi','avellino','aldo moro','piante','56412345674','antonio@gmail.com','ciao');

CREATE TABLE `azienda` (
  `sede_azienda` char(30) NOT NULL,
  `e_mail` varchar(100) DEFAULT NULL,
  `telefono` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`sede_azienda`)
);

insert into azienda values ('milano fornitorigrossisti', 'fornitorigrossisti@gmail.com','02 43542');
insert into azienda values ('napoli fornitori&grossisti', 'fornitori&grossisti@hotmail.it','081 35972');
insert into azienda values ('salerno fiori&piante&fornitura', 'fiori&piante&fornitura@gmail.com','089 63454');
insert into azienda values ('bari fornitura fiorai', 'forniturafiori_bari@outlook.com','088 585309');

CREATE TABLE `fornitore` (
  `c_f` varchar(20) NOT NULL,
  `nome` char(20) DEFAULT NULL,
  `cognome` char(30) DEFAULT NULL,
  `a_sedeAzienda` varchar(50) DEFAULT NULL,
PRIMARY KEY (`c_f`),
 KEY `a_sedeAzienda` (`a_sedeAzienda`),
  CONSTRAINT `fornitore_ibfk_1` FOREIGN KEY (`a_sedeAzienda`) REFERENCES `azienda` (`sede_azienda`) ON DELETE CASCADE
);

insert into fornitore values ('mnlgct78l89l234l','mariano','ciao','milano fornitorigrossisti');
insert into fornitore values ('ersbcc67b89l234l','ersilia','boccia','napoli fornitori&grossisti');
insert into fornitore values ('lcabsc89t89l234l','luca','boschi','salerno fiori&piante&fornitura');
insert into fornitore values ('drospl45t78b234l','dario','spulzo','bari fornitura fiorai'); 


CREATE TABLE `dipendente` (
  `cod` INT UNSIGNED AUTO_INCREMENT,
  `nome` varchar(30) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `stipendio` double NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `tipo_d` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`cod`)
);

insert into dipendente (nome,cognome,stipendio,email,password,tipo_d)values('Silvia','Castelli','1000','silvia@gmail.com','silvia','admin');
insert into dipendente (nome,cognome,stipendio,email,password,tipo_d)values('Valeria','Monzillo','1000','valeria@gmail.com','valeria','dipendenti');


CREATE TABLE `telefono` (
  `num_telefono` varchar(20) NOT NULL,
  `codice_fiscale` varchar(20) NOT NULL,
  PRIMARY KEY (`num_telefono`)
);

CREATE TABLE `prodotti` (
    `code` varchar(50) NOT NULL,
    `prezzo` double NOT NULL DEFAULT '0',
    `descrizione` text,
	`tipo` varchar(50) NOT NULL,
	`s_numero` int DEFAULT NULL,
 
  PRIMARY KEY (`code`)
);

insert into prodotti values ('887549029636',30.5,'fiori freschi','fiori',1);
insert into prodotti values ('978889719200',4.65,'fiori freschi','fiori',1);
insert into prodotti values ('614141000019',10.65,'fiori freschi','fiori',1);
insert into prodotti values ('141411234122',10,'fiori artificiali','fiori',2);
insert into prodotti values ('976669719314',10.5,'fiori artificiali','fiori',2);
insert into prodotti values ('976669717564',7.5,'fiori artificiali','fiori',2);
insert into prodotti values ('801234971920',2.59,'piante grasse','piante',3);
insert into prodotti values ('908769018300',6,'piante alte','piante',3);
insert into prodotti values ('925252111126',6.35,'piante basse','piante',3);
insert into prodotti values ('789654111121', 7.30,'oggetti per matrimonio','oggettistica',4);
insert into prodotti values ('867778608122', 6.50,'oggetti per battesimo','oggettistica',4);
insert into prodotti values ('703035555699', 7.80,'oggetti per comunione','oggettistica',4);
insert into prodotti values ('703678555643', 20.30,'oggetti per coltivazione','attrezzatura',5);
insert into prodotti values ('703678674354', 5.60,'oggetti per composizioni','attrezzatura',5);
insert into prodotti values ('456778674311', 6,'oggetti per occasioni','oggettistica',5);
insert into prodotti values ('789654321378', 15,'forbici','attrezzatura',5);
insert into prodotti values ('789654673332', 8.10,'lucido','attrezzatura',5);

 CREATE TABLE `ordinano` (
  `p_codiceBarre` varchar(50) NOT NULL,
  `d_cf` varchar(20) NOT NULL,
  `num_scaffale` int(255) DEFAULT NULL,
  PRIMARY KEY (`p_codiceBarre`,`d_cf`),
   KEY `d_cf` (`d_cf`),
  CONSTRAINT `ordinano_ibfk_1` FOREIGN KEY (`p_codiceBarre`) REFERENCES `prodotti` (`code`)
);

insert into ordinano values ('887549029636','dmnfgt95f61p099w',5);
insert into ordinano values ('978889719200','dmnfgt95f61p099w',6);
insert into ordinano values ('614141000019','dmnfgt95f61p099w',6);
insert into ordinano values ('976669719314','gvvdmn65n78l345l',1);
insert into ordinano values ('925252111126','gvvdmn65n78l345l',2);
insert into ordinano values ('867778608122','gvvdmn65n78l345l',3);
insert into ordinano values ('703035555699','gvvdmn65n78l345l',4);
insert into ordinano values ('789654673332','mrmbll78t56l897v',7);

 CREATE TABLE `fattura` (
  `CodiceVendita` INT unsigned AUTO_INCREMENT,
  `ora` TIME NOT NULL,
  `totale` double NOT NULL,
  `c_codice` bigint(255) NOT NULL,
  `data` date DEFAULT NULL,
  `stato` ENUM('IN_ELABORAZIONE','SPEDITO','CONSEGNATO') NOT NULL DEFAULT "IN_ELABORAZIONE",
  PRIMARY KEY (`CodiceVendita`)
);

insert into fattura (ora,totale,c_codice,data) values ('10:40',100.40,1,'2015-12-10');
insert into fattura (ora,totale,c_codice,data) values ('12:30',210,2,'2013-11-03');


CREATE TABLE `acquistati` (
  `CodiceVendita` INT UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `prezzo` double NOT NULL,
  `quantita` int(200) DEFAULT NULL,
  PRIMARY KEY (`code`),
  CONSTRAINT `acquistati_ibfk_1` FOREIGN KEY (`code`) REFERENCES `prodotti` (`code`)
);

insert into acquistati values (1,'887549029636',8,6);
insert into acquistati values (1,'976669719314',8,6);
insert into acquistati values (2,'978889719200',10,21);


