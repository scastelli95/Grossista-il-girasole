package it.pagecomposer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import it.javabean.UserBean;



/**
 * Servlet implementation class PageComposer
 */
@WebServlet("/PageComposer")
public class PageComposer extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public PageComposer() {
        super();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//HttpSession session=request.getSession();
		HttpSession session=request.getSession();
		String page=request.getParameter("responsepage");
		if (page==null){
			page="home";
		}
		else if(page.equals("prodotti")){
			getServletContext().getRequestDispatcher("/GetProduct").include(request, response);

		}
		else if(page.equals("dipendenti")){
			getServletContext().getRequestDispatcher("/GetAllDipendenti").include(request, response);

		}
		
		else if(page.equals("prodotto")){
			getServletContext().getRequestDispatcher("/GetProductById").include(request, response);
			getServletContext().getRequestDispatcher("/RetrieveImages").include(request, response);
		}
		else if(page.equals("login")){
			if(session.getAttribute("user")!=null){
				page=((UserBean)session.getAttribute("user")).getTipo()+"page";
				if(((UserBean)session.getAttribute("user")).getTipo().equals("user")){
					request.removeAttribute("orders");
					getServletContext().getRequestDispatcher("/GetOrders").include(request, response);
				}
				
			}
		}
		else if(page.equals("gestioneordini")){
			request.removeAttribute("orders");
				getServletContext().getRequestDispatcher("/Index").include(request, response);
		}
		else if(page.equals("userpage")){
			request.removeAttribute("orders");
				getServletContext().getRequestDispatcher("/GetOrders").include(request, response);
		}
		
	getServletContext().getRequestDispatcher("/"+page+".jsp").forward(request, response);
}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
