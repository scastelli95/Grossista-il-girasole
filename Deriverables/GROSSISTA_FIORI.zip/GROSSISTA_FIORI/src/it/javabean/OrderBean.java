package it.javabean;

import java.sql.Date;
import java.util.ArrayList;

import it.javabean.ComposizioneVenditaBean;

public class OrderBean {
	private int codice;
	private Date data;
	private double totale;
	private int c_codice;
	private ArrayList<ComposizioneVenditaBean> products;
	private String stato;
	public int getCodice() {
		return codice;
	}
	public Date getData() {
		return data;
	}
	public double getTotale() {
		return totale;
	}
	public int getC_codice() {
		return c_codice;
	}
	
	public OrderBean(int codice, Date data, double totale, int c_codice,
			ArrayList<ComposizioneVenditaBean> products, String stato) {
		this.codice = codice;
		this.data = data;
		this.totale = totale;
		this.c_codice = c_codice;
		this.products = products;
		this.stato = stato;
	}
	public ArrayList<ComposizioneVenditaBean> getProducts() {
		return products;
	}
	public String getStato(){
		return stato;
	}	

}
