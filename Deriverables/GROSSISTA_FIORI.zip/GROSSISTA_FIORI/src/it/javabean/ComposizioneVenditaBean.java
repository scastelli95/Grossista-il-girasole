package it.javabean;

import it.javabean.ProductBean;

public class ComposizioneVenditaBean {
	private ProductBean product;
	private int quantita;
	private double prezzo;
	
	public ProductBean getProduct() {
		return product;
	}
	public float getQuantita() {
		return quantita;
	}
	public double getPrezzo() {
		return prezzo;
	}
	public ComposizioneVenditaBean(ProductBean product, int quantita, double prezzo) {
		this.product = product;
		this.quantita = quantita;
		this.prezzo = prezzo;
	}
}
