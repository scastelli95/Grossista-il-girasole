package it.javabean;

public class DipendentiBean {
	int cod;
	double stipendio;
	String nome,cognome,email,tipo_d;
	
	public DipendentiBean (int cod, String nome, String cognome,Double stipendio, String email,String tipo_d) {
		this.cod=cod;
		this.nome=nome;
		this.cognome=cognome;
		this.stipendio=stipendio;
		this.email=email;
		this.tipo_d=tipo_d;
	}

	
	public double getStipendio() {
		return stipendio;
	}


	
	public String getTipo_d() {
		return tipo_d;
	}
	public int getCod() {
		return cod;
	}

	public String getNome() {
		return nome;
	}

	public String getCognome() {
		return cognome;
	}

	public String getEmail() {
		return email;
	}
	
}
