package it.javabean;

public class ProductBean {

	private String code;
	private double prezzo;
	private String descrizione;
	private int s_numero;
	private String tipo;

public ProductBean(){
	code=descrizione=tipo="";
	prezzo=s_numero=0;
}

public ProductBean(String code,double prezzo, String descrizione,int s_numero, String tipo ){
	this.code=code;
	this.prezzo=prezzo;
	this.descrizione=descrizione;
	this.s_numero=s_numero;
	this.tipo=tipo;
	
}

public String getCode() {
	return code;
}



public double getPrezzo() {
	return prezzo;
}



public String getDescrizione() {
	return descrizione;
}


public int getS_numero() {
	return s_numero;
}



public String getTipo() {
	return tipo;
}


}