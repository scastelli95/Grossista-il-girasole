package it.javabean;

public class UserBean {
		private String tipo_cliente,nome, cognome, via,partita_IVA,
		email,tipo;
		private int codice;
		private String citta,nome_negozio;
	    
		public UserBean(){
			codice=0;
			tipo=tipo_cliente=nome= cognome= via=partita_IVA=email=citta=nome_negozio="";
		}
		
		public UserBean(int codice, String tipo_cliente, String nome, String cognome,String citta, String via,String nome_negozio, String partitaIVA, String email, String tipo)
		{
			this.codice = codice;
			this.tipo_cliente=tipo_cliente;
			this.nome = nome;
			this.cognome = cognome;
			this.citta=citta;
			this.via = via;
			this.partita_IVA = partitaIVA;
			this.email = email;
			this.tipo=tipo;
			
		}
		public String getTipo_cliente() {
			return tipo_cliente;
		}
		
		public String getNome() {
			return nome;
		}
		
		public String getCognome() {
			return cognome;
		}
		
		public String getVia() {
			return via;
		}
		
		public String getPartita_IVA() {
			return partita_IVA;
		}
		
		public String getEmail() {
			return email;
		}
		
		public int getCodice() {
			return codice;
		}
		
		public String getCitta() {
			return citta;
		}
		
		public String getNome_negozio() {
			return nome_negozio;
		}
		
		public String getTipo() {
			return tipo;
		}
}
