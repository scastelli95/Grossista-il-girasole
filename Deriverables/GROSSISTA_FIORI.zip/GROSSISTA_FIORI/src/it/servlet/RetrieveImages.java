package it.servlet;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RetrieveImages
 */
@WebServlet("/RetrieveImages")
public class RetrieveImages extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RetrieveImages() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id=request.getParameter("id");
		ArrayList<String>images=new ArrayList<String>();
		String[] ext = new String[]{"gif", "png", "bmp","jpg"};
		FilenameFilter imageFilter = new FilenameFilter() {
	        @Override
	        public boolean accept(File dir, String name) {
	            for (String ext : ext) {
	                if (name.endsWith("." + ext) && !name.contains("thumbnail")) {
	                    return (true);
	                }
	            }
	            return (false);
	        }
	    };
	    File dir=new File(getServletContext().getRealPath("img/prodotti/"+id));
	    if(dir.isDirectory()){
	    	for(File f:dir.listFiles(imageFilter)){
	    		String path=f.getPath().substring(f.getPath().lastIndexOf("img\\prodotti"), f.getPath().length());
	    		images.add(path);
	    	}
	    }
	    if(images.isEmpty())
	    	images=null;
	    request.setAttribute("images", images);
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
