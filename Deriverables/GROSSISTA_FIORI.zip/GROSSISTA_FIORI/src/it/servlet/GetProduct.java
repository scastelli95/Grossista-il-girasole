package it.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.DBAccess.DBInformation;
import it.DBAccess.GetInformation;
import it.javabean.ProductBean;

/**
 * Servlet implementation class GetProduct
 */
@WebServlet("/GetProduct")
public class GetProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static GetInformation information;
    static{
    	information=new DBInformation();
    }

   
    public GetProduct() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String categories= request.getParameter("searchcat");
		ArrayList<ProductBean> products=new ArrayList<ProductBean>();
		if(categories!=null){
			if(categories.equalsIgnoreCase("all")){
				products=information.getAllProductInList();
			}
			else{
				products=information.getProductByTipo(categories);
			}	
		}
		else{
			products=information.getAllProductInList();
		}
		if(products.isEmpty())
			products=null;
		request.setAttribute("productlist", products);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
