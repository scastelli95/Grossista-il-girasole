package it.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.DBAccess.DBInformation;
import it.DBAccess.GetInformation;
import it.javabean.ProductBean;

/**
 * Servlet implementation class NewProduct
 */
@WebServlet("/NewProduct")
public class NewProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static GetInformation information;
	static {
		information=new DBInformation();
	}
    public NewProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String codiceProdotto=(String)request.getParameter("codiceProdotto");
		double prezzoAcquisto=Double.parseDouble(request.getParameter("prezzoAcquisto"));
		String descrizione = (String)request.getParameter("descrizione");
		int s_numero=Integer.parseInt(request.getParameter("s_numero"));
		String tipo=request.getParameter("tipo");
		
		String state=null;
		String link_text=null;
		if(information.createNewProduct(new ProductBean(codiceProdotto,prezzoAcquisto,
				descrizione,s_numero,tipo))){
			state="riuscita";
			link_text="Aggiungi un altro prodotto";
		}else{
			state="non riuscita";
			link_text="Errore, clicca qui per ritentare";
		}
		request.setAttribute("state",state);
		request.setAttribute("link", link_text);
		request.setAttribute("prod", codiceProdotto);
		
		request.getServletContext().getRequestDispatcher("/PageComposer?responsepage=after_add").forward(request, response);
	}


}
