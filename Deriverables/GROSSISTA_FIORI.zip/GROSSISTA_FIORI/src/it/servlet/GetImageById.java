package it.servlet;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetImageById
 */
@WebServlet("/GetImageById")
public class GetImageById extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetImageById() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("image/jpeg");
		ServletContext sc = getServletContext();
		String pId=request.getParameter("id");
		String encodings=request.getHeader("Accept-Encoding");
		String encodeFlag=request.getHeader("encoding");
		OutputStream out=response.getOutputStream();
		if((encodings!=null) && (encodings.indexOf("gzip")!= -1) && !"none".equals(encodeFlag)){
			out=new GZIPOutputStream(out);
			response.setHeader("Content-Encoding", "gzip");
		}
		if(pId!=null){
			String filename =sc.getRealPath("img/prodotti/"+pId+"/thumbnail.jpg");
			File thumbnail=null;
			try{
				thumbnail=new File(filename);
			}
			catch(Exception e){
				filename=sc.getRealPath("notfound.jpg"); 
				thumbnail=new File(filename);
			}
			BufferedImage bi = ImageIO.read(thumbnail);
			ImageIO.write(bi, "jpg", out);
			out.close();
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
