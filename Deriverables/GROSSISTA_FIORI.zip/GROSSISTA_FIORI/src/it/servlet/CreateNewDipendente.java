package it.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import it.DBAccess.DBInformation;
import it.DBAccess.GetInformation;
import it.javabean.DipendentiBean;
import it.javabean.UserBean;

/**
 * Servlet implementation class CreateNewDipendente
 */
@WebServlet("/CreateNewDipendente")
public class CreateNewDipendente extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static GetInformation information;
	static{
		information=new DBInformation();
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateNewDipendente() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		DipendentiBean dipendenti=new DipendentiBean(0,
				request.getParameter("nome"),
				request.getParameter("cognome"),
				Double.parseDouble(request.getParameter("stipendio")),
				request.getParameter("email"),
				""
				);
		String password=request.getParameter("password");
		String registrationState;
		String link;
		if(information.createNewDipendente(dipendenti, password)){
			registrationState="effettuata con successo";
			link="login";
		}
		else{
			registrationState="non riuscita";
			link="RegistraDipendente";
		}
		request.setAttribute("state", registrationState);
		request.setAttribute("link", link);
		request.getServletContext().getRequestDispatcher("/PageComposer?responsepage=after_registrationdip").forward(request, response);
		

	}

}
