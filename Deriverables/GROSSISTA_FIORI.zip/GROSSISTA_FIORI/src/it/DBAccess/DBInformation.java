package it.DBAccess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import it.DBAccess.DriverMangerConnectionPool;
import it.javabean.ProductBean;
import it.javabean.UserBean;
import it.javabean.DipendentiBean;
import it.javabean.CartBean;
import it.javabean.ComposizioneVenditaBean;
import it.javabean.OrderBean;

public class DBInformation implements GetInformation{
	public synchronized ArrayList<ProductBean> getAllProductInList() {
		ArrayList<ProductBean> allProducts=new ArrayList<ProductBean>();
		Connection connection = null;
		String getAll="SELECT * FROM prodotti;";
		try{
			connection=DriverMangerConnectionPool.getConnection();
			
			connection.commit();
			Statement st=connection.createStatement();
			ResultSet rs=st.executeQuery(getAll);
			while(rs.next()){
				allProducts.add(new ProductBean(
						rs.getString("code"),
						rs.getDouble("prezzo"),
						
						rs.getString("descrizione"),
						rs.getInt("s_numero"),
						rs.getString("tipo")
						
						));
			}
			rs.close();
			st.close();
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return allProducts;
	}
	
	public synchronized ArrayList<DipendentiBean> getAllDipendenti() {
		ArrayList<DipendentiBean> allDipendenti=new ArrayList<DipendentiBean>();
		Connection connection = null;
		String getAll="SELECT * FROM dipendente WHERE tipo_d=?;";
		try{
			connection=DriverMangerConnectionPool.getConnection();
			
			connection.commit();
			PreparedStatement ps=connection.prepareStatement(getAll);
			ps.setString(1, "dipendenti");
			Statement st=connection.createStatement();
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				allDipendenti.add(new DipendentiBean(
						rs.getInt("cod"),
						rs.getString("nome"),
						rs.getString("cognome"),
						rs.getDouble("stipendio"),
						rs.getString("email"),
						rs.getString("tipo_d")
						));
			}
			rs.close();
			st.close();
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return allDipendenti;
	}
	public synchronized ArrayList<ProductBean> getProductByTipo(String tipo){
		ArrayList<ProductBean> products=new ArrayList<ProductBean>();
		Connection connection = null;
		String getByCat="SELECT * FROM prodotti"
				+ " where(descrizione like \"%"+tipo+"%\" or "
				+ "tipo like  \"%"+tipo+"%\")"
				+"group by code;";
		try{
			connection=DriverMangerConnectionPool.getConnection();
			
			connection.commit();
			Statement st=connection.createStatement();
			ResultSet rs=st.executeQuery(getByCat);
			while(rs.next()){
				products.add(new ProductBean(
						rs.getString("code"),
						rs.getDouble("prezzo"),		
						rs.getString("descrizione"),
						rs.getInt("s_numero"),
						rs.getString("tipo")
						));
			}
			rs.close();
			st.close();
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return products;
	}
	public synchronized ProductBean getProductByCode(String code){
		String sql="SELECT * FROM prodotti WHERE code=?;";
		ProductBean product=null;
		Connection connection=null;
		try{
			connection= DriverMangerConnectionPool.getConnection();
			connection.commit();
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setString(1, code);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				product=new ProductBean(
						rs.getString("code"),
						rs.getDouble("prezzo"),		
						rs.getString("descrizione"),
						rs.getInt("s_numero"),
						rs.getString("tipo"));
			}
			rs.close();
			ps.close();
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
			return null;
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return product;
	}
	public synchronized boolean createNewProduct(ProductBean product) {
	
		
		Connection connection=null;
		String sql="INSERT INTO PRODOTTI VALUES(?,?,?,?,?);";
		try{
			
			connection=DriverMangerConnectionPool.getConnection();
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setString(1, product.getCode());
			ps.setDouble(2, product.getPrezzo());
			ps.setString(3, product.getDescrizione());
			ps.setInt(4, product.getS_numero());
			ps.setString(5, product.getTipo());
			ps.executeUpdate();
			connection.commit();
			ps.close();
			
		}
		catch(Exception e){
			System.out.println("SQLError: "+e.getMessage());
			return false;
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return true;
	}
	
	public synchronized boolean deleteProductById(String codice) {
		Connection connection= null;
		String sql="DELETE FROM PRODOTTI WHERE code=?";
				try {
					connection=DriverMangerConnectionPool.getConnection();
					PreparedStatement ps=connection.prepareStatement(sql);
					ps.setString(1, codice);
					ps.executeUpdate();
					connection.commit();
					ps.close();
				}
		catch(Exception e){
			System.out.println("SQLError: "+e.getMessage());
			return false;
		}
		finally {
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return true;
	}
	public synchronized boolean deleteDipendenteById(String codice) {
		Connection connection= null;
		String sql="DELETE FROM dipendente WHERE cod=?";
				try {
					connection=DriverMangerConnectionPool.getConnection();
					PreparedStatement ps=connection.prepareStatement(sql);
					ps.setString(1, codice);
					ps.executeUpdate();
					connection.commit();
					ps.close();
				}
		catch(Exception e){
			System.out.println("SQLError: "+e.getMessage());
			return false;
		}
		finally {
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return true;
	}
	public synchronized boolean checkEmail(String parameter) {
		String sql="SELECT email FROM clienti;";
		Connection connection=null;
		try{
			connection=DriverMangerConnectionPool.getConnection();
			Statement st=connection.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()){
				if(rs.getString(1).equals(parameter))
					return true;
			}
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
			return true;
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}		
		return false;
	}

	public synchronized ArrayList<String> getTipo() {
		ArrayList<String> categories=new ArrayList<String>();
		Connection connection=null;
		String selectCat="select distinct tipo from prodotti;";
		try {
			connection = DriverMangerConnectionPool.getConnection();
			connection.commit();
			Statement cat=connection.createStatement();
			ResultSet rs=cat.executeQuery(selectCat);
			while(rs.next()){
				categories.add(rs.getString("tipo"));
			}
			rs.close();
			cat.close();
		}
		catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
		}
		finally {
				try {
					DriverMangerConnectionPool.releaseConnection(connection);
				} catch (SQLException e) {
					System.out.println("SQLError: "+e.getMessage());
				}
		}
		return categories;
	}

	public synchronized UserBean checkUser(String username, String password) {
		UserBean user=null;
		Connection connection=null;
		String check="SELECT * FROM clienti WHERE"
				+" email=? and password=?;";
		try{
			connection=DriverMangerConnectionPool.getConnection();
			connection.commit();
			PreparedStatement ps=connection.prepareStatement(check);
			ps.setString(1, username);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			if(rs!=null && rs.next()){
				user=new UserBean(rs.getInt("codice"),
						rs.getString("tipo_cliente"),
						rs.getString("nome"),
						rs.getString("cognome"),
						rs.getString("citta"),
						rs.getString("via"),
						rs.getString("nome_negozio"),
						rs.getString("partita_IVA"),
						rs.getString("email"),
						"user"
						);
			}
			else{
			check="SELECT * FROM dipendente WHERE"
					+" email=? and password=?;";
			ps=connection.prepareStatement(check);
			ps.setString(1, username);
			ps.setString(2,password);
			rs=ps.executeQuery();
			if(rs!=null && rs.next()){
				user=new UserBean(rs.getInt("cod"),null,
						rs.getString("nome"),
						rs.getString("cognome"),
						null,
						null,
						null,
						null,
						rs.getString("email"),
						rs.getString("tipo_d"));
			}
			}
			rs.close();
			ps.close();
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
		}
		finally{
			try{
			
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		
		return user;
	}
	
	public synchronized UserBean getUserByCode(int code) {
		UserBean user=null;
		Connection connection=null;
		String check="SELECT * FROM clienti WHERE codice=?";
		try{
			connection=DriverMangerConnectionPool.getConnection();
			connection.commit();
			PreparedStatement ps=connection.prepareStatement(check);
			ps.setInt(1, code);
			ResultSet rs=ps.executeQuery();
			if(rs!=null && rs.next()){
				user=new UserBean(rs.getInt("codice"),
						rs.getString("tipo_cliente"),
						rs.getString("nome"),
						rs.getString("cognome"),
						rs.getString("citta"),
						rs.getString("via"),
						rs.getString("nome_negozio"),
						rs.getString("partita_IVA"),
						rs.getString("email"),
						"user"
						);
			}
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
		}
		finally{
			try{
			
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		
		return user;
	}
	public synchronized boolean createNewUser(UserBean user,String password) {
		String insert="INSERT INTO clienti (tipo_cliente,nome,cognome,citta,via,nome_negozio,partita_IVA,email,password) VALUES(?,?,?,?,?,?,?,?,?);";
		Connection connection=null;
		try{
			connection=DriverMangerConnectionPool.getConnection();
			
			PreparedStatement ps=connection.prepareStatement(insert);
			ps.setString(1, user.getTipo_cliente());
			ps.setString(2, user.getNome());
			ps.setString(3, user.getCognome());
			ps.setString(4, user.getCitta());
			ps.setString(5, user.getVia());
			ps.setString(6, user.getNome_negozio());
			ps.setString(7, user.getPartita_IVA());
			ps.setString(8, user.getEmail());
			ps.setString(9, password);
			ps.executeUpdate();
			connection.commit();
			ps.close();	
			return true;
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
			return false;
		}
		finally{
			try{
			
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
	}
	public synchronized boolean createNewDipendente(DipendentiBean dip,String password) {
		String insert="INSERT INTO dipendente (nome,cognome,stipendio,email,password,tipo_d) VALUES(?,?,?,?,?,?);";
		Connection connection=null;
		try{
			connection=DriverMangerConnectionPool.getConnection();
			
			PreparedStatement ps=connection.prepareStatement(insert);
			ps.setString(1, dip.getNome());
			ps.setString(2, dip.getCognome());
			ps.setDouble(3, dip.getStipendio());
			ps.setString(4, dip.getEmail());
			ps.setString(5, password);
			ps.setString(6, "dipendenti");
			ps.executeUpdate();
			connection.commit();
			ps.close();	
			return true;
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
			return false;
		}
		finally{
			try{
			
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}
	}

	public synchronized ArrayList<OrderBean> getOrderByUserId(int userId) {
		Connection connection=null;
		ArrayList<OrderBean> orders=new ArrayList<OrderBean>();
		ArrayList<ComposizioneVenditaBean> composition=new ArrayList<ComposizioneVenditaBean>();
		try{

		connection=DriverMangerConnectionPool.getConnection();
		connection.commit();
		String getVendite="SELECT * FROM fattura WHERE c_codice=?;";
		String getItem="SELECT * FROM acquistati WHERE CodiceVendita=?;";
		PreparedStatement psgetVendite=connection.prepareStatement(getVendite);
		psgetVendite.setInt(1, userId);
		ResultSet rsVendite=psgetVendite.executeQuery();
		while(rsVendite.next()){
		int codiceVendita=rsVendite.getInt("CodiceVendita");
		PreparedStatement psgetItem=connection.prepareStatement(getItem);
		psgetItem.setInt(1,codiceVendita);
		ResultSet rsGetItem=psgetItem.executeQuery();
		while(rsGetItem.next()){
		composition.add(new ComposizioneVenditaBean(
		getProductByCode(rsGetItem.getString("code")), 
		rsGetItem.getInt("quantita"), 
		rsGetItem.getDouble("prezzo")));
		}
		orders.add(new OrderBean(codiceVendita,
		rsVendite.getDate("data"), 
		rsVendite.getDouble("totale"), 
		rsVendite.getInt("c_codice"), 

		composition, 
		rsVendite.getString("stato")));
		composition=new ArrayList<ComposizioneVenditaBean>();
		rsGetItem.close();
		psgetItem.close();

		}
		rsVendite.close();
		psgetVendite.close();	
		}
		catch(SQLException e){
		System.out.println("SQLError: "+e.getMessage());
		}
		finally{
		try{

		DriverMangerConnectionPool.releaseConnection(connection);
		}
		catch(SQLException e){
		System.out.println("SQLError: "+e.getMessage());
		}
		}




		return orders;
		}

	public synchronized boolean buy(int userId, CartBean cart) {
		String insertVen="INSERT INTO fattura(ora,totale,c_codice,data,stato) VALUES(?,?,?,?,'IN_ELABORAZIONE');";
		String selectUltimaVendita="select max(CodiceVendita) as max from fattura where c_codice=?;";
		String insertComp="INSERT INTO acquistati VALUES(?,?,?,?);";

		//Attenzione aggiornamento magazzino AGGIUSTARE CON WHILE!
		Connection connection=null;
		Calendar cal=Calendar.getInstance();
		cal.setTimeInMillis(System.currentTimeMillis());
		DateFormat getData = new SimpleDateFormat("yyyy-MM-dd");
		DateFormat getOra = new SimpleDateFormat("hh:mm:ss");
		String data=getData.format(cal.getTime());
		String ora=getOra.format(cal.getTime());
		try{
		connection=DriverMangerConnectionPool.getConnection();
		PreparedStatement psInsertVen=connection.prepareStatement(insertVen);
		psInsertVen.setString(1,ora);
		double totale=0;
		ArrayList<ProductBean>products=cart.getList();
		for(ProductBean p:products){
		totale+=(p.getPrezzo()*cart.getQuantityOf(p));
		}
		psInsertVen.setDouble(2, totale);

		psInsertVen.setInt(3,userId);
		psInsertVen.setString(4,data);
		psInsertVen.executeUpdate();
		psInsertVen.close();
		PreparedStatement ultimaVendita=connection.prepareStatement(selectUltimaVendita);
		ultimaVendita.setInt(1, userId);
		ResultSet rs=ultimaVendita.executeQuery();
		rs.next();
		int codV=rs.getInt(1);
		rs.close();
		ultimaVendita.close();
		PreparedStatement psInsertComp=connection.prepareStatement(insertComp);
		psInsertComp.setInt(1, codV);
		for(ProductBean p:products){
		psInsertComp.setString(2, p.getCode());
		psInsertComp.setDouble(3,p.getPrezzo());
		psInsertComp.setFloat(4, cart.getQuantityOf(p));
		psInsertComp.executeUpdate();
		connection.commit();



		}

		connection.commit();
		psInsertComp.close();


		return true;


		}
		catch(SQLException e){
		System.out.println("SQLError: "+e.getMessage());
		return false;
		}
		finally{
		try{
		DriverMangerConnectionPool.releaseConnection(connection);
		}
		catch(SQLException e){
		System.out.println("SQLError: "+e.getMessage());
		}
		}
		}
	
	public synchronized ArrayList<OrderBean> getOrderForAdmin() {
		Connection connection=null;
		ArrayList<OrderBean> orders=new ArrayList<OrderBean>();
		ArrayList<ComposizioneVenditaBean> composition=new ArrayList<ComposizioneVenditaBean>();
		try{

		connection=DriverMangerConnectionPool.getConnection();
		connection.commit();
		String getVendite="SELECT * FROM fattura WHERE stato!=3;";
		String getItem="SELECT * FROM acquistati WHERE CodiceVendita=?;";
		PreparedStatement psgetVendite=connection.prepareStatement(getVendite);
		ResultSet rsVendite=psgetVendite.executeQuery();
		while(rsVendite.next()){
		int codiceVendita=rsVendite.getInt("CodiceVendita");
		PreparedStatement psgetItem=connection.prepareStatement(getItem);
		psgetItem.setInt(1,codiceVendita);
		ResultSet rsGetItem=psgetItem.executeQuery();
		while(rsGetItem.next()){
		composition.add(new ComposizioneVenditaBean(
		getProductByCode(rsGetItem.getString("code")), 
		rsGetItem.getInt("quantita"), 
		rsGetItem.getDouble("prezzo")));
		}
		orders.add(new OrderBean(codiceVendita,
		rsVendite.getDate("data"), 
		rsVendite.getDouble("totale"), 
		rsVendite.getInt("c_codice"), 

		composition, 
		rsVendite.getString("stato")));
		composition=new ArrayList<ComposizioneVenditaBean>();
		rsGetItem.close();
		psgetItem.close();

		}
		rsVendite.close();
		psgetVendite.close();	
		}
		catch(SQLException e){
		System.out.println("SQLError: "+e.getMessage());
		}
		finally{
		try{

		DriverMangerConnectionPool.releaseConnection(connection);
		}
		catch(SQLException e){
		System.out.println("SQLError: "+e.getMessage());
		}
		}




		return orders;
		}

	
	public synchronized boolean updateState(String id, int value) {
		Connection connection=null;
		String sql = "UPDATE fattura SET stato=? WHERE CodiceVendita=?;";
		try{
			connection=DriverMangerConnectionPool.getConnection();
			connection.commit();
			PreparedStatement ps=connection.prepareStatement(sql);
			ps.setInt(1, value);
			ps.setString(2, id);
			int v=ps.executeUpdate();
			connection.commit();
			ps.close();
			if(v==1)
				return true;
			else
				return false;
		}
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
			return false;
		}
		finally{
			try{
				DriverMangerConnectionPool.releaseConnection(connection);
			}
			catch(SQLException e){
				System.out.println("SQLError: "+e.getMessage());
			}
		}		
	}

	public synchronized ArrayList<DipendentiBean> getDipendenti() {
		Connection connection = null;
		ArrayList<DipendentiBean> dipendenti=new ArrayList<DipendentiBean>();
		String selectPV="select * from dipendenti;";
		Statement cat=null;
		try {
			connection = DriverMangerConnectionPool.getConnection();
			connection.commit();
			cat=connection.createStatement();
			ResultSet rs=cat.executeQuery(selectPV);
			while(rs.next()){
				dipendenti.add(new DipendentiBean(
						rs.getInt("codice"),
						rs.getString("nome"),
						rs.getString("cognome"),
						rs.getDouble("stipendio"),
						rs.getString("email"),
						rs.getString("tipo_d")
						));
			}
			rs.close();
			cat.close();
		} 
		catch(SQLException e){
			System.out.println("SQLError: "+e.getMessage());
		}
		finally {
			try {				
				DriverMangerConnectionPool.releaseConnection(connection);
			} catch (SQLException e) {
				System.out.println("SQLError: "+e.getMessage());
			}
		}
		return dipendenti;
	}

	
}


