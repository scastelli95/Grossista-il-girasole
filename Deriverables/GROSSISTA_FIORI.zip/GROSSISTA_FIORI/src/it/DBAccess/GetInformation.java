package it.DBAccess;

import java.util.ArrayList;

import it.javabean.CartBean;
import it.javabean.OrderBean;
import it.javabean.ProductBean;
//import it.javabean.PuntoVenditaBean;
import it.javabean.UserBean;
import it.javabean.DipendentiBean;

public interface GetInformation {
	
	

	public ArrayList<ProductBean> getProductByTipo(String tipo);
	public UserBean checkUser(String username, String password);
	public ArrayList<OrderBean> getOrderByUserId(int userId);
	public ProductBean getProductByCode(String code);
	public UserBean getUserByCode(int code);
	public boolean createNewUser(UserBean user,String password);
	public boolean createNewProduct(ProductBean product);
	public boolean createNewDipendente(DipendentiBean dip,String password);
	public boolean deleteProductById(String id);
	public boolean deleteDipendenteById(String id);
	public ArrayList<ProductBean> getAllProductInList();
	public ArrayList<DipendentiBean> getAllDipendenti();
	public ArrayList<String> getTipo();	
	
	public boolean buy(int userId, CartBean cart);
	public ArrayList<OrderBean> getOrderForAdmin();
	public boolean updateState(String id, int value);
	public boolean checkEmail(String parameter);
	public ArrayList<DipendentiBean> getDipendenti();

}
